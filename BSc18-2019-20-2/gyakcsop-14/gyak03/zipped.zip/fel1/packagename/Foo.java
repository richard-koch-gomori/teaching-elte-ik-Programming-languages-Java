

package packagename;


// a class Foo publikus: a Foo osztály kilátszik a packagename csomagból
public class Foo
{
    public int x;

    public void method()
    {
        System.out.println("x = " + x);
    }
}

