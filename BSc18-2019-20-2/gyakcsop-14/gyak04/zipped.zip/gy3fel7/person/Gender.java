
package person;


public enum Gender
{
    MALE, FEMALE
}

